# Financial formula inventory
Generated from the workbook script. All currency USD, pre-tax.

## Assumptions
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | Active businesses | `5000` | 5000.000000 |
| B6 | Queries per business per month | `4` | 4.000000 |
| B7 | Automation eligibility | `0.75` | 0.750000 |
| B8 | Resolution among eligible | `0.6` | 0.600000 |
| B9 | Baseline human handling time | `10` | 10.000000 |
| B10 | Ineligible handling time | `10` | 10.000000 |
| B11 | Escalated handling time | `10` | 10.000000 |
| B12 | Fully loaded human cost | `6` | 6.000000 |
| B13 | Model input token price | `0.4` | 0.400000 |
| B14 | Model output token price | `1.6` | 1.600000 |
| B15 | Input tokens per interaction | `1500` | 1500.000000 |
| B16 | Output tokens per interaction | `400` | 400.000000 |
| B17 | Interactions per eligible query | `3` | 3.000000 |
| B18 | Fixed infrastructure | `200` | 200.000000 |
| B19 | Internal platform revenue allocation | `5` | 5.000000 |
| B20 | Optional add-on price | `2` | 2.000000 |
| B21 | Add-on adoption | `0.2` | 0.200000 |
| B22 | Per confirmed resolution price | `0.1` | 0.100000 |
| B23 | Incremental platform/payment fees | `0` | 0.000000 |
| B24 | Cost per resolution alert | `0.05` | 0.050000 |
| B25 | Target resolution rate | `0.6` | 0.600000 |
| B26 | Repeat-contact alert | `0.15` | 0.150000 |
| B27 | Indirect tax rate | `0` | 0.000000 |
| B29 | Total estimated monthly queries | `=B5*B6` | 20000.000000 |
| B30 | Ineligible share | `=1-B7` | 0.250000 |
| B31 | Eligible escalation rate | `=1-B8` | 0.400000 |
## Volume
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | All monthly queries | `='Assumptions'!B5*'Assumptions'!B6` | 20000.000000 |
| B6 | Eligible queries | `=B5*'Assumptions'!B7` | 15000.000000 |
| B7 | Ineligible, direct to human | `=B5-B6` | 5000.000000 |
| B8 | Confirmed self-service resolutions | `=B6*'Assumptions'!B8` | 9000.000000 |
| B9 | Eligible unresolved / human demand | `=B6-B8` | 6000.000000 |
| B10 | Total human-handled demand | `=B7+B9` | 11000.000000 |
| B11 | Resolved / all queries | `=IF(B5>0,B8/B5,0)` | 0.450000 |
| B12 | Resolved / eligible (North Star) | `=IF(B6>0,B8/B6,0)` | 0.600000 |
| B13 | Human-demand share | `=IF(B5>0,B10/B5,0)` | 0.550000 |
| B14 | Query reconciliation (must be zero) | `=B5-B7-B8-B9` | 0.000000 |
| B15 | AI-processed queries | `=B6` | 15000.000000 |
## AI Costs
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | Input token cost per interaction | `='Assumptions'!B13*'Assumptions'!B15/1000000` | 0.000600 |
| B6 | Output token cost per interaction | `='Assumptions'!B14*'Assumptions'!B16/1000000` | 0.000640 |
| B7 | Token cost per interaction | `=B5+B6` | 0.001240 |
| B8 | Variable AI cost / eligible query | `=B7*'Assumptions'!B17` | 0.003720 |
| B9 | Monthly input tokens | `='Volume'!B15*'Assumptions'!B17*'Assumptions'!B15` | 67500000.000000 |
| B10 | Monthly output tokens | `='Volume'!B15*'Assumptions'!B17*'Assumptions'!B16` | 18000000.000000 |
| B11 | Monthly AI tokens cost | `='Volume'!B15*B8` | 55.800000 |
| B12 | Infrastructure | `='Assumptions'!B18` | 200.000000 |
| B13 | Incremental fees | `='Assumptions'!B23` | 0.000000 |
| B14 | Feature operating cost | `=B11+B12+B13` | 255.800000 |
| B15 | Feature cost / all queries | `=IF('Volume'!B5>0,B14/'Volume'!B5,0)` | 0.012790 |
| B16 | Feature cost / eligible query | `=IF('Volume'!B6>0,B14/'Volume'!B6,0)` | 0.017053 |
| B17 | Feature cost / confirmed resolution | `=IF('Volume'!B8>0,B14/'Volume'!B8,0)` | 0.028422 |
| B18 | Token cost reconciliation | `=B11-(B9*'Assumptions'!B13+B10*'Assumptions'!B14)/1000000` | 0.000000 |
## Human Comparison
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | Human cost per baseline query | `='Assumptions'!B9/60*'Assumptions'!B12` | 1.000000 |
| B6 | Fully human monthly baseline | `='Volume'!B5*B5` | 20000.000000 |
| B7 | Ineligible human support | `='Volume'!B7*'Assumptions'!B10/60*'Assumptions'!B12` | 5000.000000 |
| B8 | Eligible escalated human support | `='Volume'!B9*'Assumptions'!B11/60*'Assumptions'!B12` | 6000.000000 |
| B9 | Residual human cost | `=B7+B8` | 11000.000000 |
| B10 | AI and infrastructure | `='AI Costs'!B14` | 255.800000 |
| B11 | Total post-automation cost | `=B9+B10` | 11255.800000 |
| B12 | Net monthly savings | `=B6-B11` | 8744.200000 |
| B13 | Cost reduction | `=IF(B6>0,B12/B6,0)` | 0.437210 |
| B14 | Post-automation cost / all queries | `=IF('Volume'!B5>0,B11/'Volume'!B5,0)` | 0.562790 |
| B15 | Human cost per escalated query | `='Assumptions'!B11/60*'Assumptions'!B12` | 1.000000 |
| B16 | Break-even eligible resolution rate | `=IF('Volume'!B6*B15>0,MAX(0,1-(B6-B7-'AI Costs'!B14)/('Volume'!B6*B15)),-1)` | 0.017053 |
| B17 | Savings per query before fixed costs | `=B5-((1-'Assumptions'!B7)*'Assumptions'!B10/60*'Assumptions'!B12+'Assumptions'!B7*(1-'Assumptions'!B8)*B15+'Assumptions'!B7*'AI Costs'!B8)` | 0.447210 |
| B18 | Break-even monthly total queries | `=IF(B17>0,ROUNDUP(('Assumptions'!B18+'Assumptions'!B23)/B17,0),-1)` | 448.000000 |
| B19 | Break-even businesses | `=IF(B18<0,-1,IF('Assumptions'!B6>0,ROUNDUP(B18/'Assumptions'!B6,0),-1))` | 112.000000 |
## Billing
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | Included: incremental customer charge | `0` | 0.000000 |
| B6 | Included: internal allocated revenue | `='Assumptions'!B5*'Assumptions'!B19` | 25000.000000 |
| B7 | Included: variable AI costs | `='AI Costs'!B11` | 55.800000 |
| B8 | Included: fixed costs + fees | `='AI Costs'!B12+'AI Costs'!B13` | 200.000000 |
| B9 | Included: full support costs | `='Human Comparison'!B11` | 11255.800000 |
| B10 | Included: allocated support gross profit | `=B6-B9` | 13744.200000 |
| B11 | Included: allocated support margin | `=IF(B6>0,B10/B6,0)` | 0.549768 |
| B12 | Included: incremental economic benefit | `='Human Comparison'!B12` | 8744.200000 |
| B13 | Included: allocation break-even per business | `=IF('Assumptions'!B5>0,B9/'Assumptions'!B5,0)` | 2.251160 |
| B16 | Add-on subscribers | `='Assumptions'!B5*'Assumptions'!B21` | 1000.000000 |
| B17 | Add-on incremental revenue | `=B16*'Assumptions'!B20` | 2000.000000 |
| B18 | Add-on variable AI | `='AI Costs'!B11*'Assumptions'!B21` | 11.160000 |
| B19 | Add-on fixed allocation | `='Assumptions'!B18+'Assumptions'!B23` | 200.000000 |
| B20 | Add-on feature gross profit | `=B17-B18-B19` | 1788.840000 |
| B21 | Add-on feature margin | `=IF(B17>0,B20/B17,0)` | 0.894420 |
| B22 | Add-on with allocated human support | `=B20-'Human Comparison'!B9*'Assumptions'!B21` | -411.160000 |
| B23 | Add-on full-support margin | `=IF(B17>0,B22/B17,0)` | -0.205580 |
| B24 | Add-on feature break-even customers | `=IF('Assumptions'!B20-'Assumptions'!B6*'Assumptions'!B7*'AI Costs'!B8>0,ROUNDUP(B19/('Assumptions'!B20-'Assumptions'!B6*'Assumptions'!B7*'AI Costs'!B8),0),-1)` | 101.000000 |
| B27 | Usage: confirmed resolution revenue | `='Volume'!B8*'Assumptions'!B22` | 900.000000 |
| B28 | Usage: feature costs | `='AI Costs'!B14` | 255.800000 |
| B29 | Usage: feature gross profit | `=B27-B28` | 644.200000 |
| B30 | Usage: feature margin | `=IF(B27>0,B29/B27,0)` | 0.715778 |
| B31 | Usage: full-support gross profit | `=B27-'Human Comparison'!B11` | -10355.800000 |
| B32 | Usage: full-support margin | `=IF(B27>0,B31/B27,0)` | -11.506444 |
| B33 | Usage: break-even total queries | `=IF('Assumptions'!B7*'Assumptions'!B8*'Assumptions'!B22-'Assumptions'!B7*'AI Costs'!B8>0,ROUNDUP(('Assumptions'!B18+'Assumptions'!B23)/('Assumptions'!B7*'Assumptions'!B8*'Assumptions'!B22-'Assumptions'!B7*'AI Costs'!B8),0),-1)` | 4739.000000 |
## Audit and Sensitivity
| Cell | Item | Formula / assumption | Cached result |
|---|---|---|---:|
| B5 | Query count reconciliation | `='Volume'!B14` | 0.000000 |
| B6 | Token spend reconciliation | `='AI Costs'!B18` | 0.000000 |
| B7 | Feature cost per confirmed resolution | `='AI Costs'!B17` | 0.028422 |
| B8 | Cost per resolution alert | `=IF(B7>'Assumptions'!B24,1,0)` | 0.000000 |
| B9 | Zero-resolution denominator check | `=IF('Volume'!B8=0,1,0)` | 0.000000 |
| B10 | North Star below target | `=IF('Volume'!B12<'Assumptions'!B25,1,0)` | 0.000000 |
| B11 | Allocation margin below 40% | `=IF('Billing'!B11<0.40,1,0)` | 0.000000 |
| B17 | Low usage / weak automation: queries/business | `2` | 2.000000 |
| B18 | Eligibility | `0.6` | 0.600000 |
| B19 | Eligible resolution rate | `0.45` | 0.450000 |
| B20 | Monthly total queries | `='Assumptions'!B5*B17` | 10000.000000 |
| B21 | Eligible queries | `=B20*B18` | 6000.000000 |
| B22 | Confirmed resolutions | `=B21*B19` | 2700.000000 |
| B23 | Residual human queries | `=B20-B22` | 7300.000000 |
| B24 | AI plus infrastructure | `=B21*'AI Costs'!B8+'Assumptions'!B18+'Assumptions'!B23` | 222.320000 |
| B25 | Residual human costs | `=(B20-B21)*'Assumptions'!B10/60*'Assumptions'!B12+(B21-B22)*'Assumptions'!B11/60*'Assumptions'!B12` | 7300.000000 |
| B26 | Total post-automation cost | `=B24+B25` | 7522.320000 |
| B27 | Net monthly savings | `=B20*'Human Comparison'!B5-B26` | 2477.680000 |
| B28 | Cost reduction | `=IF(B20*'Human Comparison'!B5>0,B27/(B20*'Human Comparison'!B5),"N/A")` | 0.247768 |
| B29 | Feature cost/resolution | `=IF(B22>0,B24/B22,"N/A")` | 0.082341 |
| B31 | Base: queries/business | `='Assumptions'!B6` | 4.000000 |
| B32 | Eligibility | `='Assumptions'!B7` | 0.750000 |
| B33 | Eligible resolution rate | `='Assumptions'!B8` | 0.600000 |
| B34 | Monthly total queries | `='Assumptions'!B5*B31` | 20000.000000 |
| B35 | Eligible queries | `=B34*B32` | 15000.000000 |
| B36 | Confirmed resolutions | `=B35*B33` | 9000.000000 |
| B37 | Residual human queries | `=B34-B36` | 11000.000000 |
| B38 | AI plus infrastructure | `=B35*'AI Costs'!B8+'Assumptions'!B18+'Assumptions'!B23` | 255.800000 |
| B39 | Residual human costs | `=(B34-B35)*'Assumptions'!B10/60*'Assumptions'!B12+(B35-B36)*'Assumptions'!B11/60*'Assumptions'!B12` | 11000.000000 |
| B40 | Total post-automation cost | `=B38+B39` | 11255.800000 |
| B41 | Net monthly savings | `=B34*'Human Comparison'!B5-B40` | 8744.200000 |
| B42 | Cost reduction | `=IF(B34*'Human Comparison'!B5>0,B41/(B34*'Human Comparison'!B5),"N/A")` | 0.437210 |
| B43 | Feature cost/resolution | `=IF(B36>0,B38/B36,"N/A")` | 0.028422 |
| B45 | High usage / strong automation: queries/business | `8` | 8.000000 |
| B46 | Eligibility | `0.8` | 0.800000 |
| B47 | Eligible resolution rate | `0.7` | 0.700000 |
| B48 | Monthly total queries | `='Assumptions'!B5*B45` | 40000.000000 |
| B49 | Eligible queries | `=B48*B46` | 32000.000000 |
| B50 | Confirmed resolutions | `=B49*B47` | 22400.000000 |
| B51 | Residual human queries | `=B48-B50` | 17600.000000 |
| B52 | AI plus infrastructure | `=B49*'AI Costs'!B8+'Assumptions'!B18+'Assumptions'!B23` | 319.040000 |
| B53 | Residual human costs | `=(B48-B49)*'Assumptions'!B10/60*'Assumptions'!B12+(B49-B50)*'Assumptions'!B11/60*'Assumptions'!B12` | 17600.000000 |
| B54 | Total post-automation cost | `=B52+B53` | 17919.040000 |
| B55 | Net monthly savings | `=B48*'Human Comparison'!B5-B54` | 22080.960000 |
| B56 | Cost reduction | `=IF(B48*'Human Comparison'!B5>0,B55/(B48*'Human Comparison'!B5),"N/A")` | 0.552024 |
| B57 | Feature cost/resolution | `=IF(B50>0,B52/B50,"N/A")` | 0.014243 |
| B12 | No-volume / no allocated revenue flag | `=IF('Volume'!B5*'Billing'!B6=0,1,0)` | 0.000000 |
| B13 | No add-on / usage revenue flag | `=IF('Billing'!B17*'Billing'!B27=0,1,0)` | 0.000000 |
