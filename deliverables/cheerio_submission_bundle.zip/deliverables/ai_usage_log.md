# Actual AI usage and evidence log

Tool: Codex, this chat, 14 October 2026 IST. No other generative AI tool has been used or claimed. React/Vite, Chromium/Playwright, Python/XlsxWriter/openpyxl and ReportLab are implementation/validation tools, not additional AI assistants. The prototype itself uses no AI model. No customer research has been performed.

The log now records four real user inputs: the master task, two clarification replies, and the skeptical-review request. The three selected useful inputs for the report are the master task, the priority reply and the skeptical-review request. The contribution reply is retained as an attribution boundary. A failed portion of the master task produced real spreadsheet defects documented below. The same master prompt yielded useful and failed outputs; no separate failed interaction has been invented. A reviewer expecting four distinct prompt executions (three successful plus a separate failed one) may still find this overlap insufficient. Actual chat screenshots/links are outstanding.

## Useful input 1 — end-to-end assignment task
- Actual full prompt: [01-master-task.txt](ai-prompts/01-master-task.txt). Opening: “Act as a senior Product Manager, product designer, frontend engineer, AI systems designer, and business analyst working with me on a Product Intern take-home assignment for Cheerio AI.” The full file is the original uploaded text, not a reconstructed prompt.
- Purpose: convert the supplied brief into a coherent Assignment A package, with deterministic prototype, formulas, report and real evidence.
- Output: product strategy, frontend source, cost workbook, report and testing artifacts.
- Accepted: guided troubleshooting, explicit evidence labels, two-attempt ceiling and human handoff. The prototype has bounded deterministic paths rather than simulated intelligence.
- Changed: input prioritization was corrected by the user (see weak-result entry). Live pricing could not be accessed, so illustrative rates are labeled rather than presented as verified.
- Validation: Codex ran 8 state-machine tests, browser journeys, the production build, formula/cache checks and zero-denominator boundary scenarios. These are assistant-run checks, not independent user testing.
- Pranay's contribution: selected Assignment A and proposed the concept/scope in the request. His later priority decision is recorded below. Independent usability testing is pending.

## Useful input 2 — dependency and risk prioritization
- Actual full reply: [02-product-priorities.txt](ai-prompts/02-product-priorities.txt).
- Context: reply to “What would you personally change or prioritize in this proposal: a small D2C business owner troubleshooting a WhatsApp campaign, with template approval, phone connection, recipient consent, chatbot flows, and integration setup as the first five issues?”
- Purpose: supply Pranay's product judgment, rather than infer it from an AI draft.
- Output/change: phone connection is now priority 1; templates priority 2; consent priority 3. The initial pilot focuses on those three, with specialist help for risk and complexity.
- Accepted: block severity and risk can override a weighted score. The strategy makes this override explicit and treats score inputs as hypotheses.
- Validation/contribution: Pranay supplied the reasoning that connection is a prerequisite for sending. No observed ticket-frequency claim was added.
- Limitation: this reply is a real input to Codex, not a standalone user-research result.

## Attribution input — honest contribution boundary
- Actual full reply: [03-independent-contribution.txt](ai-prompts/03-independent-contribution.txt).
- Context: reply to “What work have you already done without AI—for example, using Cheerio, interviewing a user, examining support tickets, or comparing solutions?”
- Purpose: prevent the report from inventing independent research or validation.
- Output/change: report distinguishes personal assignment selection, priority/scope judgments, and escalation reasoning from Codex implementation/analysis. It marks firsthand tests and independent numerical review as pending.
- Accepted: no interviews, support-ticket review or firsthand Cheerio platform use has occurred. Future review activities are described in future tense.
- User contribution: this statement and the product prioritization are user-supplied. We cannot independently verify how the text was authored, so the report does not make broader claims of unaided research.
- Limitation: completion of the planned review must be recorded by Pranay after he actually does it.

## Useful input 3 — skeptical review (current real request)
- Actual full prompt: [04-skeptical-review.txt](ai-prompts/04-skeptical-review.txt), opening “Perform a final, skeptical hiring-manager review of the complete Cheerio Resolve Assignment A package.”
- Purpose: inspect the saved artifacts first; audit every required item; correct material defects without rebuilding the prototype.
- Actual output: read-only audit of all six saved sheets (212 initial formula cells, 218 after base-input links), independent cost and scenario arithmetic, browser checks against the existing production preview, pass/fail requirement checklist, and local corrections to seven formulas.
- Accepted changes: guard six sensitivity ratios against zero denominators; propagate the impossible-break-even sentinel; distinguish 45% overall resolution from 60% eligible resolution; make zero-revenue margin undefined; require an observed baseline rather than an assumed one.
- Validation: the first audit failed on real boundary defects, preserved in skeptical_audit_initial_results.json. After corrections, the audit passed, with all original assumptions and base numeric caches unchanged. Browser checks are assistant-run, not Pranay's independent testing.
- Pranay's contribution: requested this specific skeptical review. He still needs to decide whether the revised assumptions, scope and recommendation are defensible in his own words.

## Failed output — sanity-check portion of the actual master task
- Actual prompt excerpt: “Add sanity checks and reconciliation checks.” This is part of [01-master-task.txt](ai-prompts/01-master-task.txt), not a separately executed fourth prompt.
- Actual failure: the AI-generated workbook passed the narrow original checks but had six unguarded scenario ratios. Zero businesses or zero human cost caused division errors; zero low-scenario resolutions made cost/resolution undefined. The break-even-business formula rounded an impossible-volume sentinel of −1 into zero businesses.
- How caught: the current skeptical review evaluated the existing XLSX directly, without importing the generator that rewrites it before testing. The failure JSON contains exact sheet/cell results. No failure was deliberately manufactured or presented as a customer experiment.
- Correction: seven formulas changed. Ratios now return N/A when undefined, and impossible business break-even remains −1. Generator and visible formula inventory were synchronized, while all current inputs and cached headline outputs were preserved. Three copied base-scenario inputs were then linked to the main assumptions so changing an input updates the base comparison. The North Star now specifies confirmation within seven days of intake and cohort finalization 14 days after month-end.
- What changed in the prompt: the current review explicitly asked to inspect the existing workbook, trace every sheet, challenge assumptions, and report actual outcomes. This led to broader saved-file boundary checks rather than trusting a generator-based pass.
- Additional weak output: the initial priority ranking put templates first using unvalidated weighted scores. Pranay supplied the connection-first dependency judgment. This was a defensible alternative ranking corrected to his judgment, not a factual hallucination.
- Evidence limitation: useful and failed portions share the master prompt. Capture the actual request, failure report and correction; do not claim a fourth separate failed interaction exists.

## Additional limitations caught by checks
- Npm initially tried an unwritable home-directory cache; configuration switched to `/workspace/.npm-cache` without disabling verification.
- The model generator's first formula evaluator did not translate spreadsheet `=` comparisons into Python `==`. Generation failed visibly; corrected the evaluator and reran it. This is a genuine AI-authored implementation defect, not another user prompt.
- Pricing-page access returned a proxy 403. Therefore rates are illustrative and must be refreshed from the provider before a real budget decision.
- The initial PDF/report and worksheet numbers must be checked after any manual edits. Regenerate rather than editing headline outputs in isolation.

## Mandatory evidence still to attach
This Codex chat is not a public AI chat URL. The prompt text files and this log preserve content but are **not screenshots or publicly accessible chat evidence**.
1. Capture the actual master prompt and a representative response from this chat.
2. Capture the prioritization question, Pranay's reply, and the response acknowledging the correction.
3. Capture the skeptical-review request, initial workbook audit failure, correction and passing repeat audit. Keep the contribution clarification as supporting attribution evidence.
4. Include the master task’s actual sanity-check instruction with the failed saved-workbook output and correction. Disclose overlap with the successful master-task entry. If a separate failed prompt is required, only document a genuine new interaction that actually fails; do not fabricate one.
5. Put images in a shareable Drive folder and set Anyone with the link → Viewer. Add that real folder/chat URL in the report and final checklist.

## Independent review record — fill only after completion
- Date and device used: [pending]
- Journey tested and any difficulty observed: [pending]
- Alternative you rejected and your own reason: [pending]
- Input changed in the workbook and observed effect: [pending]
- Your final decision or revision: [pending]

Do not submit an unchanged fully AI-generated draft as independent work. The brief explicitly asks for your thinking; complete and document your review before submission.
