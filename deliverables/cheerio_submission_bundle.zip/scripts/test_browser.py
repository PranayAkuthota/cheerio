"""Functional checks and real screenshots using Chromium. Start Vite first."""
from pathlib import Path
import json,os
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'
results=[]
def check(name,fn):
 fn(); results.append({'test':name,'result':'passed'});print('PASS',name)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 context=browser.new_context(permissions=['clipboard-read','clipboard-write'],viewport={'width':1440,'height':1100},device_scale_factor=1);page=context.new_page()
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 def click(text):page.get_by_role('button',name=text,exact=True).click()
 def home():page.goto(os.environ.get('PROTOTYPE_URL','http://127.0.0.1:5173'));expect(page.get_by_role('heading',name='Let’s get you unstuck.')).to_be_visible()
 def begin():home();page.get_by_role('button',name='Guided demo My campaign isn’t sending').click()
 def diagnosis(status='Approved'):
  begin();click(status);click('Yes, it shows connected')
 def success():
  diagnosis();expect(page.get_by_role('heading',name='Check which template the campaign is using')).to_be_visible();click('I tried these steps');click('Yes, my test worked');expect(page.get_by_role('heading',name='You’re ready for the next step.')).to_be_visible()
 def empty():
  home();click('Get help');expect(page.get_by_role('alert')).to_contain_text('Describe the problem')
 def text():
  home();page.get_by_role('textbox',name='Describe your issue').fill('My campaign is stuck');click('Get help');expect(page.get_by_role('heading',name='Let’s narrow it down')).to_be_visible();click('My WhatsApp campaign isn’t sending');expect(page.get_by_role('heading',name='What does the template status say?')).to_be_visible()
 check('Empty search offers a usable error',empty)
 check('Free text leads to explicit issue identification',text)
 check('Approved template end-to-end resolution',success)
 def reopened():
  success();click('The issue came back');expect(page.get_by_role('heading',name='Let’s bring in a person')).to_be_visible();expect(page.get_by_text('Resolution retracted: issue reopened.',exact=True)).to_be_visible()
 check('Reopened success retracts outcome and hands off',reopened)
 def failed():
  diagnosis();click('I tried these steps');click('Still stuck / waiting / unable to test');expect(page.get_by_role('heading',name='One more check, then a person')).to_be_visible();click('I tried the alternative');click('Still stuck / waiting / unable to test');expect(page.get_by_role('heading',name='Let’s bring in a person')).to_be_visible();expect(page.get_by_text('Two unsuccessful attempts',exact=True)).to_be_visible()
 check('Two failed attempts mandate handoff',failed)
 with page.expect_download() as info:click('Download summary')
 download=info.value;download.save_as(OUT/'test_handoff.txt');assert 'Two unsuccessful attempts' in (OUT/'test_handoff.txt').read_text();results.append({'test':'Local summary download contains history and no-ticket notice','result':'passed'})
 def unknown():
  begin();click('I can’t find the status');expect(page.get_by_role('heading',name='Let’s avoid guessing')).to_be_visible();click('Check the status again');expect(page.get_by_role('heading',name='What does the template status say?')).to_be_visible()
 check('Missing information can be clarified and retried',unknown)
 def conflicting():
  begin();click('I see conflicting statuses');click('Ask a person');expect(page.get_by_text('Missing or conflicting template information',exact=True)).to_be_visible()
 check('Contradictory information can escalate safely',conflicting)
 def unavailable():
  begin();click('Try simulated status check');expect(page.get_by_text('Status check unavailable',exact=True)).to_be_visible();expect(page.get_by_text('No account was accessed. Choose a status you can see, or ask a person below.',exact=True)).to_be_visible()
 check('Unavailable check does not imply real account access',unavailable)
 def disconnected():
  begin();click('Approved');click('No, it is disconnected');expect(page.get_by_text('Phone/account connection needs a specialist',exact=True)).to_be_visible()
 check('Disconnected phone goes to specialist',disconnected)
 def pending():
  diagnosis('Pending review');expect(page.get_by_role('heading',name='Your selected template may still be awaiting review')).to_be_visible();click('I tried these steps');expect(page.get_by_text('Waiting is not a resolution.',exact=False)).to_be_visible()
 check('Pending review is not silently treated as resolved',pending)
 def rejected():
  diagnosis('Rejected');expect(page.get_by_text('Approval is decided by Meta.',exact=False)).to_be_visible();click('I tried these steps');expect(page.get_by_text('A resubmission alone is not a resolution.',exact=False)).to_be_visible()
 check('Rejected template has approval boundary and verification',rejected)
 def unsupported():
  home();page.get_by_role('textbox').fill('Something unfamiliar');click('Get help');click('Something else / not sure');expect(page.get_by_text('Outside the vetted demo playbook',exact=True)).to_be_visible()
 check('Unsupported issue has honest handoff',unsupported)
 def cancelled():
  begin();click('Cancel this session');expect(page.get_by_role('heading',name='Session cancelled')).to_be_visible();click('Start fresh');expect(page.get_by_role('heading',name='Let’s get you unstuck.')).to_be_visible()
 check('Cancellation is unresolved and can return home',cancelled)
 def security():
  home();page.get_by_role('textbox').fill('Account security');click('Get help');click('Account, security or billing issue');expect(page.get_by_text('Security, payment or account restriction',exact=True)).to_be_visible()
 check('Sensitive issues never enter automatic fixes',security)
 def topics():
  for name in ['Getting started Connect your WhatsApp number','Safety first Check recipient eligibility','Specialist help My chatbot isn’t responding','Specialist help Connect an integration']:
   home();page.get_by_role('button',name=name,exact=False).click();expect(page.get_by_role('heading',name='Let’s bring in a person')).to_be_visible()
 check('Non-demo topic cards disclose specialist boundaries',topics)
 def audit():
  begin();click('View demo audit events');expect(page.locator('.events')).to_contain_text('START');expect(page.locator('.events')).to_contain_text('SUPPORTED');click('Support home');expect(page.locator('.events')).to_contain_text('No events yet.')
 check('Local event preview records transitions and resets',audit)
 def help():
  home();click('Help resources');expect(page.get_by_role('dialog')).to_be_visible();click('Got it');expect(page.get_by_role('dialog')).not_to_be_visible()
 check('Help resources dialog opens and closes',help)
 def keyboard():
  home();click('Help resources');page.keyboard.press('Shift+Tab');assert page.evaluate('document.activeElement.textContent').startswith('Got it');page.keyboard.press('Tab');expect(page.get_by_role('button',name='Close help resources')).to_be_focused();page.keyboard.press('Escape');expect(page.get_by_role('dialog')).not_to_be_visible()
 check('Help dialog traps Tab and supports Escape',keyboard)
 def clipboard():
  home();click('Prepare human handoff');click('Copy summary');expect(page.get_by_role('status')).to_contain_text('Summary copied')
 check('Handoff summary copy works in browser',clipboard)

 # Four actual screenshots, all captured from the application.
 home();page.screenshot(path=OUT/'screenshots/01-support-home.png',full_page=True)
 begin();page.screenshot(path=OUT/'screenshots/02-guided-troubleshooting.png',full_page=True)
 click('Approved');click('Yes, it shows connected');page.screenshot(path=OUT/'screenshots/03-diagnosis.png',full_page=True)
 click('I tried these steps');click('Still stuck / waiting / unable to test');click('I tried the alternative');click('Still stuck / waiting / unable to test');page.screenshot(path=OUT/'screenshots/04-human-escalation.png',full_page=True)
 # Responsive sanity checks at phone and tablet sizes.
 for width,height in [(390,844),(768,1024)]:
  page.set_viewport_size({'width':width,'height':height})
  for scene in [home,diagnosis,failed]:
   scene();assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth'),f'Horizontal overflow at {width}'
  results.append({'test':f'No horizontal overflow at {width}px: home, diagnosis, handoff','result':'passed'})
 page.set_viewport_size({'width':390,'height':844});home();page.screenshot(path=OUT/'screenshots/mobile-support-home.png',full_page=True)
 assert not errors,errors
 results.append({'test':'No browser runtime exceptions','result':'passed'})
 browser.close()
(OUT/'browser_test_results.json').write_text(json.dumps(results,indent=2))
print(len(results),'browser checks passed')
