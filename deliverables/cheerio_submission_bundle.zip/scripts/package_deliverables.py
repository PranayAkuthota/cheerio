"""Package source and review artifacts without dependencies, Git metadata or credentials."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'deliverables'
site=OUT/'cheerio_resolve_site.zip';bundle=OUT/'cheerio_submission_bundle.zip'
with ZipFile(site,'w',ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'dist').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT/'dist'))
root_files=['.gitignore','README.md','package.json','package-lock.json','index.html','vite.config.js','requirements-dev.txt']
files=[ROOT/x for x in root_files]
for folder in ['src','docs','scripts','deliverables']:
 for p in sorted((ROOT/folder).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p!=bundle and p.name not in ['test_handoff.txt','file_manifest.md']:
   files.append(p)
# Test downloads belong to validation, not the submission package.
(OUT/'test_handoff.txt').unlink(missing_ok=True)
manifest=OUT/'file_manifest.md'
lines=['# Files created','All paths are absolute in this cloud workspace. Installed dependencies and build-cache files are omitted.','']
for p in files:lines.append(f'- `{p}`')
lines +=[f'- `{manifest}`',f'- `{bundle}`','', 'The static-site ZIP contains only the deployable built site. The submission bundle contains source, report, workbook, screenshots and review records. Neither ZIP contains credentials, node_modules, Git metadata, original uploaded attachments or the cloud cache.']
manifest.write_text('\n'.join(lines)+'\n');files.append(manifest)
with ZipFile(bundle,'w',ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(ROOT))
for p in [site,bundle]:
 with ZipFile(p) as z:assert z.testzip() is None;print(p,len(z.namelist()),'files',p.stat().st_size,'bytes; ZIP integrity passed')
