"""Generate formula-preserving workbook with evaluated cached results; no live customer data."""
from pathlib import Path
import math, re, json, ast
import xlsxwriter
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'
OUT.mkdir(exist_ok=True)
S={}; notes={}; labels={}; units={}; cached={}
def row(sheet,r,label,value,unit='',note=''):
 S.setdefault(sheet,{})['B'+str(r)]=value
 labels[(sheet,r)]=label;units[(sheet,r)]=unit;notes[(sheet,r)]=note
A='Assumptions';V='Volume';C='AI Costs';H='Human Comparison';B='Billing';U='Audit and Sensitivity'
inputs=[
(5,'Active businesses',5000,'businesses','Only supplied operating input; assignment PDF Part 4.'),
(6,'Queries per business per month',4,'queries/business/month','Hypothesis; validate on tickets, not known Cheerio data.'),
(7,'Automation eligibility',.75,'fraction','Frozen intake taxonomy. Ineligible cases receive rule-based intake, no AI cost here.'),
(8,'Resolution among eligible',.60,'fraction','Month-three hypothesis; user-confirmed with seven-day no-reopen window.'),
(9,'Baseline human handling time',10,'minutes/query','Fully human baseline; illustrative.'),
(10,'Ineligible handling time',10,'minutes/query','No assumed time savings.'),
(11,'Escalated handling time',10,'minutes/query','Conservative: no efficiency credit for handoff.'),
(12,'Fully loaded human cost',6,'USD/hour','Illustrative loaded rate; validate wages, overhead, shifts.'),
(13,'Model input token price',.40,'USD/million tokens','Illustrative GPT-4.1 mini-style rates, NOT live-verified. Source reference https://openai.com/api/pricing/ ; access attempted 2026-10-14, blocked HTTP proxy 403.'),
(14,'Model output token price',1.60,'USD/million tokens','Illustrative, not a claim of current pricing. No cache/batch discounts assumed.'),
(15,'Input tokens per interaction',1500,'tokens','Includes retrieved instructions/history; assumed, instrument actual use.'),
(16,'Output tokens per interaction',400,'tokens','Assumed average.'),
(17,'Interactions per eligible query',3,'interactions/query','Average across success/escalation; includes failed calls. Not prototype API usage.'),
(18,'Fixed infrastructure',200,'USD/month','Hypothesis for hosting, logs, retrieval and monitoring. Excludes engineering and one-time implementation.'),
(19,'Internal platform revenue allocation',5,'USD/business/month','Accounting assumption only. Not actual Cheerio plan price and not incremental revenue.'),
(20,'Optional add-on price',2,'USD/business/month','Alternative, not recommended. No paywall on human support.'),
(21,'Add-on adoption',.20,'fraction','Assumed adopter usage/eligibility equal to population.'),
(22,'Per confirmed resolution price',.10,'USD/resolution','Alternative; never bill failed attempts or handoffs. False-resolution incentives still problematic.'),
(23,'Incremental platform/payment fees',0,'USD/month','Existing invoices assumed; no incremental processing fee. Change if processor costs are material.'),
(24,'Cost per resolution alert',.05,'USD/resolution','Feature cost only; proposed budget threshold.'),
(25,'Target resolution rate',.60,'fraction','NS target, not baseline or observed performance.'),
(26,'Repeat-contact alert',.15,'fraction','Proposed threshold, not known benchmark.'),
(27,'Indirect tax rate',0,'fraction','Model excludes taxes: all prices/costs pre-tax; jurisdiction and recoverability unknown. Validate before billing.')]
for args in inputs:row(A,*args)
row(A,29,'Total estimated monthly queries','=B5*B6','queries/month','Derived; mirrored in Volume.')
row(A,30,'Ineligible share','=1-B7','fraction','Complement, not additive to escalations.')
row(A,31,'Eligible escalation rate','=1-B8','fraction','Among eligible; all unconfirmed/abandoned episodes remain unresolved.')
row(V,5,'All monthly queries',"='Assumptions'!B5*'Assumptions'!B6",'queries')
row(V,6,'Eligible queries',"=B5*'Assumptions'!B7",'queries')
row(V,7,'Ineligible, direct to human','=B5-B6','queries')
row(V,8,'Confirmed self-service resolutions',"=B6*'Assumptions'!B8",'queries')
row(V,9,'Eligible unresolved / human demand','=B6-B8','queries','Includes abandonment until reconciled; budget human cost conservatively even if not yet delivered.')
row(V,10,'Total human-handled demand','=B7+B9','queries','Ineligible plus unresolved eligible, mutually exclusive.')
row(V,11,'Resolved / all queries','=B8/B5','fraction','Not the North Star denominator.')
row(V,12,'Resolved / eligible (North Star)','=B8/B6','fraction')
row(V,13,'Human-demand share','=B10/B5','fraction')
row(V,14,'Query reconciliation (must be zero)','=B5-B7-B8-B9','queries')
row(V,15,'AI-processed queries','=B6','queries','All eligible episodes incur average AI cost, including escalated ones.')
row(C,5,'Input token cost per interaction',"='Assumptions'!B13*'Assumptions'!B15/1000000",'USD/interaction')
row(C,6,'Output token cost per interaction',"='Assumptions'!B14*'Assumptions'!B16/1000000",'USD/interaction')
row(C,7,'Token cost per interaction','=B5+B6','USD/interaction')
row(C,8,'Variable AI cost / eligible query',"=B7*'Assumptions'!B17",'USD/query')
row(C,9,'Monthly input tokens',"='Volume'!B15*'Assumptions'!B17*'Assumptions'!B15",'tokens')
row(C,10,'Monthly output tokens',"='Volume'!B15*'Assumptions'!B17*'Assumptions'!B16",'tokens')
row(C,11,'Monthly AI tokens cost',"='Volume'!B15*B8",'USD/month')
row(C,12,'Infrastructure',"='Assumptions'!B18",'USD/month')
row(C,13,'Incremental fees',"='Assumptions'!B23",'USD/month')
row(C,14,'Feature operating cost','=B11+B12+B13','USD/month','Excludes residual human support, engineering and taxes.')
row(C,15,'Feature cost / all queries',"=B14/'Volume'!B5",'USD/query')
row(C,16,'Feature cost / eligible query',"=B14/'Volume'!B6",'USD/query')
row(C,17,'Feature cost / confirmed resolution',"=IF('Volume'!B8>0,B14/'Volume'!B8,0)",'USD/resolution','Zero placeholder if no resolutions; denominator sanity check flags that condition.')
row(C,18,'Token cost reconciliation',"=B11-(B9*'Assumptions'!B13+B10*'Assumptions'!B14)/1000000",'USD; must be zero')
row(H,5,'Human cost per baseline query',"='Assumptions'!B9/60*'Assumptions'!B12",'USD/query')
row(H,6,'Fully human monthly baseline',"='Volume'!B5*B5",'USD/month')
row(H,7,'Ineligible human support',"='Volume'!B7*'Assumptions'!B10/60*'Assumptions'!B12",'USD/month')
row(H,8,'Eligible escalated human support',"='Volume'!B9*'Assumptions'!B11/60*'Assumptions'!B12",'USD/month')
row(H,9,'Residual human cost','=B7+B8','USD/month')
row(H,10,'AI and infrastructure',"='AI Costs'!B14",'USD/month')
row(H,11,'Total post-automation cost','=B9+B10','USD/month')
row(H,12,'Net monthly savings','=B6-B11','USD/month')
row(H,13,'Cost reduction','=B12/B6','fraction')
row(H,14,'Post-automation cost / all queries',"=B11/'Volume'!B5",'USD/query')
row(H,15,'Human cost per escalated query',"='Assumptions'!B11/60*'Assumptions'!B12",'USD/query')
row(H,16,'Break-even eligible resolution rate',"=MAX(0,1-(B6-B7-'AI Costs'!B14)/('Volume'!B6*B15))",'fraction','If above 1, this cost structure cannot break even. No handling-time benefit assumed.')
row(H,17,'Savings per query before fixed costs',"=B5-((1-'Assumptions'!B7)*'Assumptions'!B10/60*'Assumptions'!B12+'Assumptions'!B7*(1-'Assumptions'!B8)*B15+'Assumptions'!B7*'AI Costs'!B8)",'USD/query')
row(H,18,'Break-even monthly total queries',"=IF(B17>0,ROUNDUP(('Assumptions'!B18+'Assumptions'!B23)/B17,0),-1)",'queries','-1 means impossible under selected assumptions.')
row(H,19,'Break-even businesses',"=ROUNDUP(B18/'Assumptions'!B6,0)",'businesses','-1 means no feasible break-even business count under selected assumptions.')
row(B,5,'Included: incremental customer charge',0,'USD/month','Recommended included support: incremental revenue is zero and feature cost is $255.80/month in the base case. Standalone feature gross margin is undefined at zero revenue; savings are cost avoidance, not sales.')
row(B,6,'Included: internal allocated revenue',"='Assumptions'!B5*'Assumptions'!B19",'USD/month','Internal allocation, not newly earned revenue or actual Cheerio pricing.')
row(B,7,'Included: variable AI costs',"='AI Costs'!B11",'USD/month')
row(B,8,'Included: fixed costs + fees',"='AI Costs'!B12+'AI Costs'!B13",'USD/month')
row(B,9,'Included: full support costs',"='Human Comparison'!B11",'USD/month','AI, infrastructure and residual people.')
row(B,10,'Included: allocated support gross profit','=B6-B9','USD/month')
row(B,11,'Included: allocated support margin','=B10/B6','fraction','Hypothetical internally allocated margin only, not actual platform gross margin or incremental feature margin. Actual profitability requires real platform revenue and all relevant costs.')
row(B,12,'Included: incremental economic benefit',"='Human Comparison'!B12",'USD/month','Avoided modeled costs, not guaranteed cash savings; headcount capacity may be redeployed.')
row(B,13,'Included: allocation break-even per business',"=B9/'Assumptions'!B5",'USD/business/month')
row(B,16,'Add-on subscribers',"='Assumptions'!B5*'Assumptions'!B21",'businesses')
row(B,17,'Add-on incremental revenue',"=B16*'Assumptions'!B20",'USD/month')
row(B,18,'Add-on variable AI',"='AI Costs'!B11*'Assumptions'!B21",'USD/month')
row(B,19,'Add-on fixed allocation',"='Assumptions'!B18+'Assumptions'!B23",'USD/month','Conservative: add-on absorbs all fixed feature infrastructure.')
row(B,20,'Add-on feature gross profit','=B17-B18-B19','USD/month','Excludes existing human support.')
row(B,21,'Add-on feature margin','=B20/B17','fraction')
row(B,22,'Add-on with allocated human support',"=B20-'Human Comparison'!B9*'Assumptions'!B21",'USD/month','Separate full-support scope; avoids presenting feature margin as total support margin.')
row(B,23,'Add-on full-support margin','=B22/B17','fraction')
row(B,24,'Add-on feature break-even customers',"=IF('Assumptions'!B20-'Assumptions'!B6*'Assumptions'!B7*'AI Costs'!B8>0,ROUNDUP(B19/('Assumptions'!B20-'Assumptions'!B6*'Assumptions'!B7*'AI Costs'!B8),0),-1)",'businesses','Feature costs only; not full support.')
row(B,27,'Usage: confirmed resolution revenue',"='Volume'!B8*'Assumptions'!B22",'USD/month','Alternative; never charge failed attempts or human handoffs.')
row(B,28,'Usage: feature costs',"='AI Costs'!B14",'USD/month')
row(B,29,'Usage: feature gross profit','=B27-B28','USD/month')
row(B,30,'Usage: feature margin','=B29/B27','fraction')
row(B,31,'Usage: full-support gross profit',"=B27-'Human Comparison'!B11",'USD/month')
row(B,32,'Usage: full-support margin','=B31/B27','fraction')
row(B,33,'Usage: break-even total queries',"=IF('Assumptions'!B7*'Assumptions'!B8*'Assumptions'!B22-'Assumptions'!B7*'AI Costs'!B8>0,ROUNDUP(('Assumptions'!B18+'Assumptions'!B23)/('Assumptions'!B7*'Assumptions'!B8*'Assumptions'!B22-'Assumptions'!B7*'AI Costs'!B8),0),-1)",'queries','Feature scope only.')
row(U,5,'Query count reconciliation',"='Volume'!B14",'must equal zero','Alert any mismatch; deduplicate by episode ID, reconcile raw events vs warehouse.')
row(U,6,'Token spend reconciliation',"='AI Costs'!B18",'must equal zero','Production: match provider invoice token counts, model version, retries and cache discounts; alert >2% variance.')
row(U,7,'Feature cost per confirmed resolution',"='AI Costs'!B17",'USD/resolution','Alert above Assumptions B24 ($0.05); sample long conversations, compare usage assumptions.')
row(U,8,'Cost per resolution alert',"=IF(B7>'Assumptions'!B24,1,0)",'1=alert, 0=clear')
row(U,9,'Zero-resolution denominator check',"=IF('Volume'!B8=0,1,0)",'1=alert','Do not interpret the zero cost/resolution placeholder as healthy.')
row(U,10,'North Star below target',"=IF('Volume'!B12<'Assumptions'!B25,1,0)",'1=alert','Monthly matured cohorts only. Review abandonment and reopen rates, do not change eligibility after outcome.')
row(U,11,'Allocation margin below 40%',"=IF('Billing'!B11<0.40,1,0)",'1=alert','Reforecast cost and support staffing; do not obstruct handoffs.')
for start,name,q,e,r in [(17,'Low usage / weak automation',2,.60,.45),(31,'Base',4,.75,.60),(45,'High usage / strong automation',8,.80,.70)]:
 row(U,start,name+': queries/business',"='Assumptions'!B6" if start==31 else q,'queries/business/month','Base follows main assumptions; low/high are independent scenarios.')
 row(U,start+1,'Eligibility',"='Assumptions'!B7" if start==31 else e,'fraction')
 row(U,start+2,'Eligible resolution rate',"='Assumptions'!B8" if start==31 else r,'fraction')
 row(U,start+3,'Monthly total queries',f"='Assumptions'!B5*B{start}",'queries')
 row(U,start+4,'Eligible queries',f'=B{start+3}*B{start+1}','queries')
 row(U,start+5,'Confirmed resolutions',f'=B{start+4}*B{start+2}','queries')
 row(U,start+6,'Residual human queries',f'=B{start+3}-B{start+5}','queries')
 row(U,start+7,'AI plus infrastructure',f"=B{start+4}*'AI Costs'!B8+'Assumptions'!B18+'Assumptions'!B23",'USD/month')
 row(U,start+8,'Residual human costs',f"=(B{start+3}-B{start+4})*'Assumptions'!B10/60*'Assumptions'!B12+(B{start+4}-B{start+5})*'Assumptions'!B11/60*'Assumptions'!B12",'USD/month')
 row(U,start+9,'Total post-automation cost',f'=B{start+7}+B{start+8}','USD/month')
 row(U,start+10,'Net monthly savings',f"=B{start+3}*'Human Comparison'!B5-B{start+9}",'USD/month')
 row(U,start+11,'Cost reduction',f'=IF(B{start+3}*\'Human Comparison\'!B5>0,B{start+10}/(B{start+3}*\'Human Comparison\'!B5),"N/A")','fraction','N/A means zero denominator, not healthy performance.')
 row(U,start+12,'Feature cost/resolution',f'=IF(B{start+5}>0,B{start+7}/B{start+5},"N/A")','USD/resolution','N/A means zero resolutions; cost per resolution is undefined.')
# Guard editable denominators; zero means unavailable and is flagged, not healthy.
for sh,cell,denom in [
 (V,'B11','B5'),(V,'B12','B6'),(V,'B13','B5'),
 (C,'B15',"'Volume'!B5"),(C,'B16',"'Volume'!B6"),
 (H,'B13','B6'),(H,'B14',"'Volume'!B5"),
 (B,'B11','B6'),(B,'B13',"'Assumptions'!B5"),
 (B,'B21','B17'),(B,'B23','B17'),(B,'B30','B27'),(B,'B32','B27')]:
 S[sh][cell]=f'=IF({denom}>0,{S[sh][cell][1:]},0)'
 notes[(sh,int(cell[1:]))]+=' Zero denominator returns a placeholder zero; interpret as unavailable, not a positive outcome.'
S[H]['B16']="=IF('Volume'!B6*B15>0,MAX(0,1-(B6-B7-'AI Costs'!B14)/('Volume'!B6*B15)),-1)"
S[H]['B19']="=IF(B18<0,-1,IF('Assumptions'!B6>0,ROUNDUP(B18/'Assumptions'!B6,0),-1))"
row(U,12,'No-volume / no allocated revenue flag',"=IF('Volume'!B5*'Billing'!B6=0,1,0)",'1=alert','Zero-denominator rates/margins are unavailable placeholders. Do not interpret as healthy.')
row(U,13,'No add-on / usage revenue flag',"=IF('Billing'!B17*'Billing'!B27=0,1,0)",'1=alert','Alternative margins unavailable if no adopters or resolutions.')
# Restricted arithmetic evaluator for the exact generated formula subset.
def evaluate(sheet,cell):
 key=(sheet,cell)
 if key in cached:return cached[key]
 v=S[sheet][cell]
 if not isinstance(v,str) or not v.startswith('='):cached[key]=v;return v
 expr=v[1:]
 def ref(m):return repr(evaluate(m.group(1) or sheet,m.group(2)))
 expr=re.sub(r"(?:'([^']+)'!)?\b([A-Z]+[0-9]+)\b",ref,expr)
 expr=re.sub(r'(?<![<>!=])=(?!=)', '==', expr)
 expr=expr.replace('ROUNDUP(','roundup(').replace('MAX(','max(').replace('IF(','choose(')
 tree=ast.parse(expr,mode='eval')
 class LazyIF(ast.NodeTransformer):
  def visit_Call(self,node):
   node=self.generic_visit(node)
   if isinstance(node.func,ast.Name) and node.func.id=='choose':
    return ast.copy_location(ast.IfExp(test=node.args[0],body=node.args[1],orelse=node.args[2]),node)
   return node
 tree=ast.fix_missing_locations(LazyIF().visit(tree))
 value=eval(compile(tree,'<formula>','eval'),{'__builtins__':{}},{'max':max,'roundup':lambda x,n:math.ceil(x*10**n)/10**n})
 cached[key]=value;return value
wb=xlsxwriter.Workbook(OUT/'cheerio_financial_model.xlsx')
wb.set_properties({'title':'Cheerio Resolve — assumptions, costs and billing','author':'Pranay Akuthota with Codex assistance','comments':'Hypothetical model; not actual Cheerio operating data.'})
wb.set_calc_mode('auto')
fmt_title=wb.add_format({'bold':True,'font_size':19,'font_color':'#206E55'})
fmt_sub=wb.add_format({'font_size':10,'font_color':'#718474','text_wrap':True})
fmt_head=wb.add_format({'bold':True,'bg_color':'#206E55','font_color':'white','text_wrap':True})
fmt_label=wb.add_format({'text_wrap':True,'valign':'top','font_size':10})
fmt_input=wb.add_format({'bg_color':'#EDF4FD','font_color':'#275BA4','num_format':'0.0000','valign':'top'})
fmt_num=wb.add_format({'num_format':'#,##0.0000','valign':'top','font_color':'#24583E'})
fmt_percent=wb.add_format({'num_format':'0.00%','valign':'top','font_color':'#24583E'})
fmt_formula=wb.add_format({'font_size':9,'font_color':'#6C806E','text_wrap':True,'valign':'top'})
for sheet,cells in S.items():
 ws=wb.add_worksheet(sheet);ws.hide_gridlines(2);ws.freeze_panes(4,1);ws.set_landscape();ws.fit_to_pages(1,0);ws.repeat_rows(0,3)
 ws.set_column('A:A',44);ws.set_column('B:B',18);ws.set_column('C:C',25);ws.set_column('D:D',58);ws.set_column('E:E',80)
 ws.merge_range('A1:E1','Cheerio Resolve | '+sheet,fmt_title);ws.set_row(0,31)
 ws.merge_range('A2:E2','All currency USD, pre-tax. Blue = editable assumption; green = formula result. Formula text is visible in column D. No actual Cheerio operating data.',fmt_sub);ws.set_row(1,32)
 ws.write_row('A4',['Item','Value','Unit','Visible formula / input','Assumption, source or interpretation'],fmt_head)
 for cell,v in cells.items():
  r=int(cell[1:]);ws.set_row(r-1,64 if sheet==B and r in [5,11] else 46)
  ws.write(r-1,0,labels[(sheet,r)],fmt_label);ws.write(r-1,2,units[(sheet,r)],fmt_label);ws.write(r-1,4,notes[(sheet,r)],fmt_label)
  if isinstance(v,str) and v.startswith('='):
   val=evaluate(sheet,cell);f=fmt_percent if units[(sheet,r)]=='fraction' else fmt_num
   ws.write_formula(cell,v,f,val)
   ws.write_formula(r-1,3,f'=FORMULATEXT(B{r})',fmt_formula,v)
   ws.write_comment(cell,notes[(sheet,r)]+'\n'+v)
  else:
   ws.write(cell,v,fmt_input);ws.write(r-1,3,'Editable assumption / input',fmt_formula)
  if sheet==A and r in [7,8,21,25,26,27]:ws.data_validation(cell,{'validate':'decimal','criteria':'between','minimum':0,'maximum':1})
  elif sheet==A and 5<=r<=27:ws.data_validation(cell,{'validate':'decimal','criteria':'>=','value':0})
# Add non-numeric operational audit plan below scenarios.
ws=wb.get_worksheet_by_name(U)
audit=[('Usage ledger','Any mismatch','Match distinct business+issue IDs across intake, success, reopen, escalation, and abandonment. Never count retries as new paid episodes.'),('Human handoff','Any undelivered handoff','Compare requested, sent and acknowledged handoffs; replay delivery failures, flag missing context.'),('Repeat or failed conversations','Repeat contacts >15% or attempts >2','Sample redacted histories; identify unclear guidance. Prototype limits to two attempts; production enforce this.'),('Unexpected usage spikes','Queries/tokens >30% over forecast','Segment by business/topic; rate-limit abuse with safe human fallback. Include failed API calls in token ledger.'),('Model price changes','Any published price change','Verify provider invoice and official price source; update Assumptions B13/B14 and reforecast before next billing cycle.'),('Revenue/billing','Any bill for unresolved case or >1% ledger/invoice mismatch','Reconcile invoice totals, credits, discounts, tax, deduplication and permissioned usage. Included recommendation has zero new Resolve bill.'),('Margin deterioration','Allocated support margin <40%','Investigate volume, eligibility and human time; reforecast, do not hide access to a person.'),('Privacy / unsafe advice','Any incident','Stop affected playbook; specialist incident review; redact evidence, enforce least privilege and retention limits.'),('North Star integrity','Any false confirmation; seven-day cohort incomplete','Retract reopened successes; finalize only matured cohorts, audit 5% of redacted success episodes.')]
for i,(name,threshold,action) in enumerate(audit,62):
 ws.set_row(i-1,46);ws.write(i-1,0,name,fmt_label);ws.write(i-1,1,threshold,fmt_label);ws.merge_range(i-1,2,i-1,4,action,fmt_label)
wb.close()
# Verify category conservation and independent headline arithmetic.
expected={'queries':5000*4,'eligible':5000*4*.75,'resolved':5000*4*.75*.6,'ai':15000*3*(1500*.4+400*1.6)/1e6,'human':11000*10/60*6}
assert evaluate(V,'B5')==expected['queries']
assert evaluate(V,'B8')==expected['resolved']
assert evaluate(V,'B14')==0
assert abs(evaluate(C,'B11')-expected['ai'])<1e-9
assert abs(evaluate(H,'B9')-expected['human'])<1e-9
assert abs(evaluate(H,'B12')-(20000-11000-expected['ai']-200))<1e-9
for start in [17,31,45]:assert evaluate(U,f'B{start+3}')==evaluate(U,f'B{start+5}')+evaluate(U,f'B{start+6}')
headlines={sheet:{cell:evaluate(sheet,cell) for cell in cells} for sheet,cells in S.items()}
(OUT/'financial_results.json').write_text(json.dumps(headlines,indent=2))
lines=['# Financial formula inventory','Generated from the workbook script. All currency USD, pre-tax.\n']
for sheet,cells in S.items():
 lines+=['## '+sheet,'| Cell | Item | Formula / assumption | Cached result |','|---|---|---|---:|']
 for cell,v in cells.items():lines.append(f'| {cell} | {labels[(sheet,int(cell[1:]))]} | `{v}` | {evaluate(sheet,cell):.6f} |')
(OUT/'financial_formulas.md').write_text('\n'.join(lines))
print(json.dumps({'total_queries':evaluate(V,'B5'),'resolved':evaluate(V,'B8'),'feature_cost':evaluate(C,'B14'),'full_cost':evaluate(H,'B11'),'savings':evaluate(H,'B12'),'savings_pct':evaluate(H,'B13'),'allocated_support_margin':evaluate(B,'B11'),'break_even_queries':evaluate(H,'B18')},indent=2))
