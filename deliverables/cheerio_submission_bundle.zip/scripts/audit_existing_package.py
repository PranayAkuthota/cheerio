"""Read-only audit of existing XLSX/PDF and browser journeys; no project/workbook rebuild."""
from pathlib import Path
import ast, re, math, json, tempfile, hashlib, sys
import openpyxl
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'deliverables/skeptical_audit_results.json'
book=ROOT/'deliverables/cheerio_financial_model.xlsx'
f=openpyxl.load_workbook(book,data_only=False)
c=openpyxl.load_workbook(book,data_only=True)
class Evaluator:
 def __init__(self,overrides=None):self.overrides=overrides or {};self.cache={}
 def cell(self,sheet,cell):
  key=(sheet,cell)
  if key in self.overrides:return self.overrides[key]
  if key in self.cache:return self.cache[key]
  val=f[sheet][cell].value
  if not isinstance(val,str) or not val.startswith('='):return val
  ft=re.fullmatch(r'=FORMULATEXT\((\w+\d+)\)',val)
  if ft:return f[sheet][ft[1]].value
  def ref(m):return f'REF({m[1] or sheet!r},{m[2]!r})'
  expr=re.sub(r"(?:'([^']+)'!)?\b([A-Z]+[0-9]+)\b",ref,val[1:])
  expr=re.sub(r'(?<![<>!=])=(?!=)','==',expr)
  tree=ast.parse(expr,mode='eval')
  class LazyIF(ast.NodeTransformer):
   def visit_Call(self,node):
    node=self.generic_visit(node)
    if isinstance(node.func,ast.Name) and node.func.id=='IF':return ast.copy_location(ast.IfExp(node.args[0],node.args[1],node.args[2]),node)
    return node
  tree=ast.fix_missing_locations(LazyIF().visit(tree))
  val=eval(compile(tree,'<spreadsheet-audit>','eval'),{'__builtins__':{}},{'REF':self.cell,'MAX':max,'ROUNDUP':lambda x,n:math.ceil(x*10**n)/10**n})
  self.cache[key]=val;return val
checks=[]
def check(name,fn):
 try:details=fn();checks.append({'check':name,'status':'PASS','details':details})
 except Exception as e:checks.append({'check':name,'status':'FAIL','details':str(e)})
def formulas():
 n=0;e=Evaluator()
 for s in f:
  for row in s:
   for cell in row:
    if cell.data_type=='f':
     actual=e.cell(s.title,cell.coordinate);cache=c[s.title][cell.coordinate].value
     assert cache is not None,(s.title,cell.coordinate,'missing cache')
     if isinstance(actual,(int,float)):assert math.isclose(actual,cache,abs_tol=1e-8,rel_tol=1e-10),(s.title,cell.coordinate,actual,cache)
     else:assert actual==cache,(s.title,cell.coordinate,actual,cache)
     n+=1
 return {'sheets':len(f.sheetnames),'formulas_recalculated_and_cache_matched':n}
check('All existing formulas and references recalculated independently of generator',formulas)
def trace():
 e=Evaluator();get=e.cell
 q=get('Assumptions','B5')*get('Assumptions','B6');eligible=q*get('Assumptions','B7');res=eligible*get('Assumptions','B8');human=q-res
 ai=eligible*get('Assumptions','B17')*(get('Assumptions','B15')*get('Assumptions','B13')+get('Assumptions','B16')*get('Assumptions','B14'))/1e6
 infrastructure=get('Assumptions','B18')+get('Assumptions','B23');people=((q-eligible)*get('Assumptions','B10')+(eligible-res)*get('Assumptions','B11'))*get('Assumptions','B12')/60
 baseline=q*get('Assumptions','B9')*get('Assumptions','B12')/60
 expected=[('Volume','B5',q),('Volume','B6',eligible),('Volume','B8',res),('Volume','B10',human),('AI Costs','B11',ai),('Human Comparison','B9',people),('Human Comparison','B12',baseline-people-ai-infrastructure)]
 for sh,cell,v in expected:assert math.isclose(get(sh,cell),v,abs_tol=1e-8)
 assert q==(q-eligible)+res+(eligible-res)
 rev=get('Assumptions','B5')*get('Assumptions','B19');profit=rev-people-ai-infrastructure
 assert math.isclose(get('Billing','B10'),profit,abs_tol=1e-8)
 assert math.isclose(get('Billing','B11'),profit/rev,abs_tol=1e-8)
 return {'total_queries':q,'eligible':eligible,'automated':res,'remaining_human':human,'ai_cost':ai,'residual_human_cost':people,'feature_cost':ai+infrastructure,'full_cost':people+ai+infrastructure,'net_savings':baseline-people-ai-infrastructure,'allocated_revenue':rev,'allocated_gross_profit':profit,'allocated_margin':profit/rev}
check('Volume, token units, residual people and allocated margin trace',trace)
def scenarios():
 result={};e=Evaluator()
 for label,start in [('low',17),('base',31),('high',45)]:
  q=5000*e.cell('Audit and Sensitivity',f'B{start}');eligible=q*e.cell('Audit and Sensitivity',f'B{start+1}');res=eligible*e.cell('Audit and Sensitivity',f'B{start+2}')
  ai=eligible*.00372;people=q-res;full=people+ai+200;savings=q-full
  for offset,v in [(3,q),(4,eligible),(5,res),(6,q-res),(7,ai+200),(8,people),(9,full),(10,savings),(11,savings/q),(12,(ai+200)/res)]:assert math.isclose(e.cell('Audit and Sensitivity',f'B{start+offset}'),v,abs_tol=1e-8)
  result[label]={'queries':q,'eligible':eligible,'resolved':res,'human':q-res,'feature_cost':ai+200,'full_cost':full,'savings':savings,'feature_cost_per_resolution':(ai+200)/res}
 return result
check('Low/base/high scenarios independently recomputed',scenarios)
def billing():
 e=Evaluator()
 for sh,cell,v in [('Human Comparison','B16',255.8/15000),('Human Comparison','B18',448),('Human Comparison','B19',112),('Billing','B17',2000),('Billing','B20',1788.84),('Billing','B21',.89442),('Billing','B22',-411.16),('Billing','B23',-.20558),('Billing','B24',101),('Billing','B27',900),('Billing','B29',644.2),('Billing','B30',644.2/900),('Billing','B31',-10355.8),('Billing','B33',4739)]:assert math.isclose(e.cell(sh,cell),v,abs_tol=1e-8)
 return 'Add-on and usage-based feature/full-support margins and break-even traced; included incremental revenue is zero, so standalone margin is undefined.'
check('Billing alternatives and break-even',billing)
def base_alignment():
 e=Evaluator({('Assumptions','B6'):5})
 for sh,cell,v in [('Volume','B5',25000),('Volume','B8',11250),('AI Costs','B14',269.75),('Human Comparison','B12',10980.25),('Audit and Sensitivity','B34',25000),('Audit and Sensitivity','B41',10980.25)]:assert math.isclose(e.cell(sh,cell),v,abs_tol=1e-8),(sh,cell)
 return 'Assumptions B6=5 updates main and base-scenario totals/costs/savings; low/high remain independent scenarios. In-memory only; workbook input restored/preserved at 4.'
check('Editable main assumptions update the base scenario',base_alignment)

def boundaries():
 cases={
  'zero resolutions':{('Assumptions','B8'):0},
  'zero adopters':{('Assumptions','B21'):0},
  'zero query frequency':{('Assumptions','B6'):0},
  'zero eligible share':{('Assumptions','B7'):0},
  'zero businesses':{('Assumptions','B5'):0},
  'zero human cost':{('Assumptions','B12'):0},
  'zero low-scenario resolutions':{('Audit and Sensitivity','B19'):0}}
 errors=[]
 for label,overrides in cases.items():
  e=Evaluator(overrides)
  for s in f:
   for row in s:
    for cell in row:
     if cell.data_type=='f':
      try:e.cell(s.title,cell.coordinate)
      except Exception as ex:errors.append((label,s.title,cell.coordinate,str(ex)))
  if label=='zero human cost' and e.cell('Human Comparison','B18')==-1:
   if e.cell('Human Comparison','B19')!=-1:errors.append((label,'Human Comparison','B19','Impossible-volume -1 incorrectly becomes zero businesses'))
 assert not errors,errors
 return list(cases)
check('Editable-input boundaries across all six sheets',boundaries)
def report():
 p=PdfReader(ROOT/'deliverables/cheerio_assignment_A.pdf')
 assert len(p.pages)==4;assert len(p.pages[2].images)==4
 text='\n'.join(page.extract_text() for page in p.pages)
 for n in ['20,000','15,000','9,000','11,000','55.80','255.80','11,255.80','8,744.20','43.72','25,000','13,744.20','54.98','1,788.84','89.44','411.16','20.56','644.20','71.58','10,355.80','2,477.68','22,080.96']:
  assert n in text,f'Missing expected headline {n}'
 assert 'ADD ACTUAL PUBLIC URL' in text and 'ADD ACTUAL SHARED SHEET URL' in text and 'ADD EVIDENCE URL' in text
 return {'pages':4,'embedded_screenshots':4,'headline_text_present':True,'public_URLs':'clearly outstanding'}
check('Existing PDF page count, screenshots, headlines and URL placeholders',report)
if '--skip-browser' in sys.argv:
 previous=json.loads(OUTPUT.read_text())
 browser=next(x for x in previous['checks'] if x['check']=='Existing production browser regression suite')
 assert browser['status']=='PASS','No passing browser result available to retain'
 browser['details']['retained_from_previous_run']=True
 checks.append(browser)
else:
 # Run existing browser checks with output redirected to scratch; retain submission screenshots.
 tmp=Path(tempfile.mkdtemp(prefix='cheerio-review-'));(tmp/'screenshots').mkdir()
 source=(ROOT/'scripts/test_browser.py').read_text().replace("OUT=ROOT/'deliverables'",f"OUT=Path({str(tmp)!r})")
 check('Existing production browser regression suite',lambda:exec(compile(source,str(ROOT/'scripts/test_browser.py'),'exec'),{'__file__':str(ROOT/'scripts/test_browser.py')}))
 if (tmp/'browser_test_results.json').exists():
  checks[-1]['details']={'passed':len(json.loads((tmp/'browser_test_results.json').read_text())),'fresh_screenshots_and_download':str(tmp),'submission_screenshots':'preserved'}
OUTPUT.write_text(json.dumps({'checks':checks,'workbook_sha256':hashlib.sha256(book.read_bytes()).hexdigest()},indent=2))
print(json.dumps(checks,indent=2))
raise SystemExit(1 if any(x['status']=='FAIL' for x in checks) else 0)
