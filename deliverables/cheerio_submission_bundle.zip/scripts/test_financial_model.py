from pathlib import Path
import importlib.util,json,openpyxl
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('model',ROOT/'scripts/build_financial_model.py');model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
f=openpyxl.load_workbook(ROOT/'deliverables/cheerio_financial_model.xlsx',data_only=False)
v=openpyxl.load_workbook(ROOT/'deliverables/cheerio_financial_model.xlsx',data_only=True)
count=0
for sheet in f:
 for row in sheet:
  for c in row:
   if c.data_type=='f':
    assert v[sheet.title][c.coordinate].value is not None,(sheet.title,c.coordinate)
    count+=1
assert len(f.sheetnames)==6
assert v['Volume']['B14'].value==0
assert abs(v['AI Costs']['B18'].value)<1e-9
assert v['Volume']['B7'].value+v['Volume']['B8'].value+v['Volume']['B9'].value==v['Volume']['B5'].value
assert v['Human Comparison']['B9'].value==11000
assert abs(v['Human Comparison']['B12'].value-8744.2)<1e-9
# Boundary scenarios: no resolutions, no paid users, and zero query volume.
model.S['Assumptions']['B8']=0;model.cached.clear()
assert model.evaluate('Volume','B10')==20000
assert model.evaluate('Audit and Sensitivity','B9')==1
assert model.evaluate('Human Comparison','B12')<0
model.S['Assumptions']['B21']=0;model.cached.clear()
assert model.evaluate('Billing','B21')==0
assert model.evaluate('Audit and Sensitivity','B13')==1
model.S['Assumptions']['B6']=0;model.cached.clear()
assert model.evaluate('Volume','B5')==0
assert model.evaluate('AI Costs','B15')==0
assert model.evaluate('Audit and Sensitivity','B12')==1
assert model.evaluate('Human Comparison','B12')==-200
r={'sheets':6,'formulas_with_cached_values':count,'query_reconciliation':0,'token_cost_reconciliation':0,'independent_headline_crosschecks':'passed','boundary_scenarios':['zero resolutions','zero add-on adoption','zero query volume'],'google_sheets_import':'not executed; requires user upload'}
(ROOT/'deliverables/workbook_test_results.json').write_text(json.dumps(r,indent=2))
print('PASS',r)
