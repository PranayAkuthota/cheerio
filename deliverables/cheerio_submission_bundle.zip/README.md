# Cheerio Resolve

A clickable Assignment A concept for Cheerio's Product Intern take-home. Guided support for non-technical business owners, with clear evidence labels and a human handoff. **Not an existing Cheerio product.** No backend, API credentials, account access, real AI calls, real tickets or real messages.

## Run

Requirements: Node.js >=22.12 (tested with 24.19.0), npm (tested with 11.9.0). Use the existing checkout `/workspace/cheerio`; the cloud task is already isolated, so no Git worktree is needed.

```sh
cd /workspace/cheerio
npm --cache /workspace/.npm-cache ci --no-audit --no-fund
npm run dev -- --port 5173
```

Use the development server on your own local machine or the available environment access. Loopback addresses are for internal checks, not publicly shareable submission links.

```sh
npm test
npm run build
npm run preview -- --port 4173
```

`dist/` is a complete static site; no server-side service is required for deployment. Deploy its contents at the site root. Dependencies are pinned and package-lock.json is included. The cache flag avoids this environment's unwritable home-directory npm cache. TLS and package integrity checks remain enabled.

## Implemented interactions

- Home search validates empty input and leads to an explicit issue selector; text is not AI-interpreted.
- Campaign/template card starts the complete demo journey. Approved, pending and rejected statuses lead to different guidance.
- Targeted phone-connection question; unknown/disconnected cases go to a person.
- Missing/contradictory status clarification and retry; simulated check deliberately returns unavailable.
- Safe steps and user test confirmation; waiting/resubmission alone is not presented as success.
- One alternate check, then mandatory handoff after two unsuccessful attempts.
- Person request available throughout; no paywall or repetitive bot loop.
- Resolution can be reopened; cancellation stays unresolved; reset returns home.
- Handoff summary can be copied/downloaded locally, with timestamp and history. It clearly states no ticket was created.
- Other topic cards disclose specialist boundaries. They are not fully implemented troubleshooting flows.
- Help resources modal supports keyboard focus containment and Escape.
- Session-only audit preview and JSON export; reset clears events. No persistent storage or analytics transmission.
- Desktop, tablet and phone layouts; actual screenshots in `deliverables/screenshots/`.

The sidebar's Overview/Campaigns/Contacts/Automations labels are visual platform context, not clickable modules. All real primary controls are functional. Fictional workspace/campaign data are visibly identified. User answers are not independent account evidence.

## Test the journey

1. Choose **My campaign isn’t sending**.
2. Choose **Approved**, then **Yes, it shows connected**.
3. Review the possible-cause label and instructions. Choose **I tried these steps**.
4. Choose **Yes, my test worked** for resolution; use **The issue came back** to retract it and hand off.
5. Repeat with **Still stuck** twice to see mandatory escalation. Download and inspect the handoff summary.
6. Explore pending/rejected, unknown/conflicting status, unavailable simulated check, cancellation, security and unsupported issues.

Assistant-run checks are not customer usability tests. Pranay still needs to test and review independently.

## Browser and document tools

The cloud machine already provides Python, Chromium, Playwright, XlsxWriter, openpyxl, ReportLab and pypdf. Optional generator requirements are pinned in `requirements-dev.txt`. For another machine, install in a virtual environment and install Chromium through your OS or Playwright. `CHROMIUM_PATH` overrides the system browser path used by the tests.

```sh
# With the dev server running:
python scripts/test_browser.py
# Against the built site with npm run preview running:
PROTOTYPE_URL=http://127.0.0.1:4173 python scripts/test_browser.py
python scripts/test_financial_model.py
python scripts/build_report.py
```

The browser check captures **real** screenshots and records results in `deliverables/browser_test_results.json`. Financial tests rebuild the workbook, check formulas/cached values, and test zero-resolution, zero-adoption and zero-volume cases. Run report generation after any workbook or screenshot changes. The PDF generator rejects anything other than four pages.

The financial generator uses standard XLSX formulas plus FORMULATEXT columns. Cached results make the workbook readable before recalculation. Google Sheets import has not been executed here; upload, inspect formula cells and change an input before submission.

## Artifacts and handoff

- `docs/product-strategy.md`: detailed hypotheses, prioritization, scope and metrics.
- `deliverables/cheerio_assignment_A.pdf`: exact four-page AI-assisted review draft.
- `deliverables/cheerio_assignment_A.md`: editable matching report source.
- `deliverables/cheerio_financial_model.xlsx`: six formula-preserving sheets.
- `deliverables/financial_formulas.md`: formula inventory and calculated results.
- `deliverables/ai_usage_log.md` and `ai-prompts/`: real inputs and honest contribution boundaries.
- `deliverables/submission_checklist.md`: deployment, Google Sheets, sharing and submission steps.
- `deliverables/final_review.md`: requirement coverage, tests and remaining limitations.
- `deliverables/file_manifest.md`: complete file paths.

No public URLs or AI chat screenshots have been fabricated. The supplied brief rejects fully AI-generated submissions; treat this as a draft to understand, review and change where your judgment requires it.

## Audit an existing submission safely

`PROTOTYPE_URL=http://127.0.0.1:4173 python scripts/audit_existing_package.py` reads the current XLSX/PDF and tests the existing preview without regenerating the workbook or overwriting submission screenshots. After document-only changes, `python scripts/audit_existing_package.py --skip-browser` reruns financial/PDF checks and explicitly retains the previous browser result. The older `test_financial_model.py` imports the generator and rewrites base artifacts; use it only when intentionally regenerating, after preserving manual edits.
