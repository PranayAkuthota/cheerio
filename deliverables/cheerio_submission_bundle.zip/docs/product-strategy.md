# Cheerio Resolve: guided support for business owners

Proposed assignment concept, not an existing Cheerio feature. Assignment A only.

## What is known / what is assumed
The supplied PDF says Cheerio's users are largely business owners and marketing teams, and that support struggles as users grow. It names WhatsApp setup, templates, flows and integrations as common friction. It supplies 5,000 active businesses for the guesstimate. It does not supply ticket frequencies, costs, resolution rates, or customer research. All scores and operating inputs below are hypotheses to validate. No user interviews or actual account inspections have been conducted.

## User and job
A small D2C store owner runs promotions herself, shares support duties with one teammate, and cannot debug APIs. She wants an opted-in campaign to send on time without accidentally duplicating messages. A confusing status, long documentation and repeatedly explaining the same problem waste time. She needs clear next steps, honest evidence, and access to a person. The prototype uses a fictional store, Mogra Studio, and a fictional Diwali preview campaign.

## Five initial issues
Scores 1–5, higher is better. Frequency (F) 30%, impact (I) 30%, safe self-service feasibility (S) 25%, business value (V) 15%. Weighted score = .30F+.30I+.25S+.15V. Estimated frequency is a relative hypothesis, not measured ticket share. Ties favor safer implementation. Pranay overrides the raw score to put phone connection first because it blocks all sending; this explicit risk/dependency judgment precedes numeric ranking.

| Rank | Issue | F | I | S | V | Score | Reason / safe boundary |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | WhatsApp number/account not connected | 4 | 5 | 3 | 5 | 4.20 | Blocks first value; guided status check, then specialist for ownership, restrictions or verification. |
| 2 | Campaign blocked by template status or wrong selected template | 5 | 5 | 4 | 5 | 4.75 | Time-critical; status and selected-template checks are understandable. Never promise Meta approval. |
| 3 | Recipient format, consent or eligibility | 4 | 4 | 4 | 4 | 4.00 | High campaign impact; explain format and consent. Never bypass opt-in or 24-hour/template rules. |
| 4 | Chatbot flow not triggering | 3 | 4 | 4 | 4 | 3.70 | Check published state and entry conditions with a controlled test. No automatic production edits. |
| 5 | Integration credentials or webhook configuration | 3 | 4 | 2 | 4 | 3.20 | Business-critical but secret-sensitive; use redacted evidence and early specialist escalation. |

## Alternatives and selection
Same transparent 1–5 framework for solution choices: user usefulness (U) 35%, coverage (C) 25%, safety (S) 25%, delivery ease (E) 15%. These are AI-assisted hypothesis scores pending Pranay’s independent review and observation; they are not experimentally established.

| Option | U | C | S | E | Weighted | Trade-off |
|---|---:|---:|---:|---:|---:|---|
| Better self-service documentation | 2 | 3 | 5 | 5 | 3.45 | Cheap and necessary, but users must translate instructions to their case. |
| Searchable help center | 3 | 3 | 5 | 4 | 3.65 | Finds articles; does not establish whether an issue is fixed. |
| Rule-based guided troubleshooting | 4 | 3 | 5 | 4 | 4.00 | Safe, consistent baseline; limited language flexibility. |
| Generic AI support assistant | 4 | 4 | 2 | 4 | 3.50 | Flexible language; can hallucinate status or unsafe fixes. |
| Context-aware AI with account access | 5 | 5 | 3 | 1 | 3.90 | High utility but permissions, API reliability and privacy delay a safe launch. |
| Human support escalation | 5 | 5 | 5 | 2 | 4.55 | Strong service baseline, but fails the scaling goal on its own. |
| Proactive onboarding / alerts | 4 | 2 | 4 | 3 | 3.35 | Prevents issues; cannot resolve all current problems. |
| Guided rules + constrained AI + handoff | 5 | 4 | 5 | 3 | 4.45 | Chosen: useful language with bounded approved steps, and a person when needed. |

Pranay personally selected Assignment A and supplied the first-five ordering and initial three-issue scope. He has not interviewed customers, reviewed actual tickets, or used the platform firsthand. He will independently review alternatives, test the journey, and inspect financial assumptions before submitting; those activities are pending.

A score ranks value, but a feasibility gate matters: human-only fails the mandatory scaling objective despite its high score. The selected hybrid combines a small rule-based tree, approved help content, AI interpretation/explanation, and mandatory handoff. In the prototype all behavior is deterministic; no real AI model or account integration runs. An initial production pilot should start with the first three issues, with flows and integrations routed to existing help or a specialist until vetted playbooks exist. This avoids implementing every feature before testing the main hypothesis.

## Chosen journey and scope
Describe/select issue → targeted status questions → evidence-labeled diagnosis → small safe action → ask user to test → confirm or retry once → handoff with history. A template case is the implemented end-to-end example. Other cards offer honest scope boundaries and escalation, not fictional completed flows. The account panel is fictional sample context; each fact is labeled demo, user-reported or unavailable.

Included: understandable approved steps, source labels, unknown/contradictory inputs, one alternative after a failed attempt, cancellation, summary review/copy/download, and a session-only event log. Excluded: production account changes, template submission/approval, bulk sending, handling secrets, autonomous billing changes, actual tickets, and a backend. In production AI may classify redacted text and explain approved guidance. Rules gate actions and escalation. Retrieved content should be versioned; instruction-like text in customer messages must never override the approved workflow. No arbitrary actions based on model output.

## Human boundary
Mandatory human: account suspension/ownership, payment/security/privacy issues, credentials, no safe playbook, conflicting evidence that remains unresolved, or two unsuccessful attempts. User can request a human at any point. An unavailable account check offers manual status input or immediate handoff; it never invents a result. Unknown/conflicting answers offer another clarification or a handoff; human access is always visible. The demo does not impose a clarification-count limit. Handoff includes the user's wording, campaign, consented/redacted status answers, source and time, attempted steps, outcome, and reason. Never include tokens or message/recipient content. User reviews before sharing. No ticket is created by the demo; it downloads a handoff summary for existing support. A production queue should display actual delivery status and response expectations from live queue data; no invented SLA.

## Measurement and target
North Star: **confirmed self-service resolution rate among eligible support queries** = distinct eligible issue episodes resolved without a human / distinct eligible issue episodes opened in a monthly cohort. Eligibility is assigned at intake using a frozen taxonomy, independent of success; security/billing/ownership cases are ineligible. An issue episode joins repeated contacts for the same business+campaign+problem within seven days. Resolution requires explicit confirmation of a successful user test within seven days of intake, without a human, followed by seven days with no same-issue reopen. Finalize each monthly intake cohort 14 days after month-end so every episode has the full opportunity and follow-up window. Report provisional and matured rates separately. Count abandonment, unanswered verification, confirmation after the seven-day deadline, and reopened cases as unresolved. Audit a redacted sample to catch false confirmations and do not exclude difficult eligible cases after intake.

Three supporting metrics: (1) median and p90 time to confirmed resolution for successful episodes, paired with abandonment; (2) seven-day repeat-contact rate across eligible episodes; (3) successful handoff rate = acknowledged handoffs with the required context / all requested or mandatory handoffs (failed delivery stays in denominator). Segment by topic, language and customer tenure; track privacy incidents and CSAT as guardrails, not alternate North Stars.

Three-month hypothesis: aim for 60% of eligible queries. A hypothetical 45% starting baseline would mean +15 percentage points (+33% relative), but the actual pilot baseline must be measured and the target rebased if it differs; no baseline has been observed. Month 1 instrument cohorts and audit the first 100 eligible episodes. Month 2 fix two top failure branches and improve approved explanations. Month 3 add vetted recipient troubleshooting and reduce repeated clarification. Keep human access visible and stop rollout if repeat contacts or safety incidents rise. The workbook uses the month-three 60% assumption, not a claimed day-one outcome. Validate the 75% eligible share and 4 queries/business/month before budget approval.

## Research next
Review 100 redacted tickets, interview five non-technical owners, and usability-test the full flow with five participants. Rank actual topic frequency and observe whether users can identify template status without assistance. Pilot with a holdout using identical eligibility definitions. These are proposed activities, not completed research.

## Skeptical review: majority and commercial limits
At 75% eligibility and 60% eligible success, the pilot resolves 45% of all support queries. It therefore does not yet meet the brief’s ambition to resolve most queries. At a fixed 75% eligible share, a majority needs more than 66.7% eligible success; expanding eligibility is another possible path, but both require validated playbooks, not a relabeled denominator. Keep the current 60% pilot target as an honest hypothesis, and assess majority coverage after the first cohort rather than inflate assumptions.

The included feature has zero incremental revenue and adds $255.80 monthly feature expense in the base case. Standalone feature gross margin is undefined; the $8,744.20 benefit is potential cost avoidance. The 54.98% figure uses a hypothetical $5/business internal revenue allocation; actual platform profitability cannot be inferred from it. Negative full-support margins for optional add-on/usage billing do not prove the incremental options are unprofitable, because these scopes exclude existing platform revenue. Their feature-only margins are the more relevant incremental comparison, with inclusion preferred for adoption and incentive reasons.
