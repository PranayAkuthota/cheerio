import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,transition as t,handoff} from './flow.js';
function base(status='approved') {return t(t(t(t(initial(),'START','Campaign not sending'),'SUPPORTED'),'STATUS',status),'CONNECTION','connected');}
test('successful campaign flow requires an attempted fix and user confirmation',()=>{let s=t(base(),'TRY'); assert.equal(s.stage,'verify');s=t(s,'FIXED');assert.equal(s.stage,'resolved');assert.match(s.history.at(-1),/not independently verified/);});
test('two unsuccessful attempts force escalation',()=>{let s=t(t(base(),'TRY'),'NOT_FIXED');assert.equal(s.stage,'retry');s=t(t(s,'TRY'),'NOT_FIXED');assert.equal(s.stage,'escalate');assert.equal(s.attempts,2);});
test('unknown and contradictory inputs cannot become diagnoses',()=>{for(const v of ['unknown','conflicting']) {const s=t(t(initial(),'SUPPORTED'),'STATUS',v);assert.equal(s.stage,'clarify');}});
test('disconnected phone escalates with source labeling',()=>{const s=t(t(initial(),'STATUS','approved'),'CONNECTION','disconnected');assert.equal(s.stage,'escalate');assert.match(handoff(s),/user-reported/);});
test('unavailable check does not invent an account status',()=>{const s=t(t(initial(),'START','Help'),'CHECK');assert.equal(s.check,'unavailable');assert.equal(s.status,'');assert.match(s.history[0],/no account was accessed/);});
test('cancel and reset discard outcome without counting resolution',()=>{const s=t(base(),'CANCEL');assert.equal(s.stage,'cancelled');assert.match(s.history.at(-1),/do not count/);assert.deepEqual(t(s,'HOME'),initial());});
test('reopened confirmation is retracted and escalated',()=>{const s=t(t(t(base(),'TRY'),'FIXED'),'REOPEN');assert.equal(s.stage,'escalate');assert.match(s.history.at(-1),/retracted/);});
test('unsupported case and sensitive case route directly to a person',()=>{assert.equal(t(initial(),'UNSUPPORTED').stage,'escalate');assert.equal(t(initial(),'HUMAN','Account security').reason,'Account security');});
