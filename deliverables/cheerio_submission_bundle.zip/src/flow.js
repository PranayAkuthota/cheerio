export const initial = () => ({stage:'home', issue:'', status:'', connection:'', attempts:0, history:[], events:[], reason:'', check:'idle'});
export function transition(s, action, value='') {
 const event = {name:action, value, at:new Date().toISOString()};
 const n = {...s, events:[...s.events,event]};
 switch(action) {
  case 'START': return {...n,stage:'identify',issue:value};
  case 'SUPPORTED': return {...n,stage:'status',history:[...s.history,'Campaign/template issue selected (user-reported).']};
  case 'UNSUPPORTED': return {...n,stage:'escalate',reason:'Outside the vetted demo playbook'};
  case 'STATUS': return {...n,status:value,stage:['unknown','conflicting'].includes(value)?'clarify':'connection',history:[...s.history,`Template status: ${value} (user-reported).`]};
  case 'CLARIFY': return {...n,stage:'status'};
  case 'CONNECTION': return {...n,connection:value,stage:value==='disconnected'?'escalate':'diagnosis',reason:value==='disconnected'?'Phone/account connection needs a specialist':'',history:[...s.history,`Phone connection: ${value} (user-reported).`]};
  case 'CHECK': return {...n,check:'unavailable',history:[...s.history,'Simulated account check unavailable; no account was accessed.']};
  case 'TRY': return {...n,stage:'verify',attempts:s.attempts+1,history:[...s.history,`User reports attempting suggested ${s.status} step (${s.attempts+1}).`]};
  case 'FIXED': return {...n,stage:'resolved',history:[...s.history,'User confirmed test success; not independently verified.']};
  case 'NOT_FIXED': return {...n,stage:s.attempts>=2?'escalate':'retry',reason:s.attempts>=2?'Two unsuccessful attempts':'',history:[...s.history,'User reports issue still unresolved.']};
  case 'HUMAN': return {...n,stage:'escalate',reason:value||'User requested a person'};
  case 'CANCEL': return {...n,stage:'cancelled',history:[...s.history,'User cancelled; do not count as resolved.']};
  case 'REOPEN': return {...n,stage:'escalate',reason:'Same issue reopened after confirmation',history:[...s.history,'Resolution retracted: issue reopened.']};
  case 'HOME': return initial();
  default:return s;
 }
}
export function handoff(s) {
 return `CHEERIO RESOLVE — DEMO HANDOFF\nNo ticket has been created.\nPrepared at: ${s.events.at(-1)?.at || 'Unknown'} (local demo timestamp)\n\nIssue: ${s.issue||'Not supplied'}\nCampaign: Diwali preview (fictional sample)\nReason: ${s.reason}\nTemplate: ${s.status||'Unknown'} (user-reported)\nPhone: ${s.connection||'Unknown'} (user-reported)\nAttempts: ${s.attempts}\n\nHistory:\n${s.history.map(x=>'- '+x).join('\n')||'- No troubleshooting attempted.'}\n\nReview and redact before sharing with your existing support channel. Do not include passwords, access tokens, or recipient lists.`;
}
